# Gabbro Website

A simple static website themed around gabbro stone.

## Features
- Dark theme design
- Informational layout
- Ready for GitHub

## How to Use
1. Download zip
2. Extract files
3. Open index.html in browser

## Author
Mortification Records
